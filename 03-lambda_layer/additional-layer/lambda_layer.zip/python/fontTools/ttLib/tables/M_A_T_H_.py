from .otBase import BaseTTXConverter


class table_M_A_T_H_(BaseTTXConverter):
    pass
